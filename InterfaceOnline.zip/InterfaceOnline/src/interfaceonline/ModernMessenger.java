/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceonline;

/**
 *
 * @author Asus
 */
public interface ModernMessenger extends Messenger {
    public void sendPhoto(String x, String y);
    public void receivePhoto(String x, String y);
    
}
