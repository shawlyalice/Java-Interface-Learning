/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceonline;

/**
 *
 * @author Asus
 */
public interface Messenger extends GenericCommunicationSoftware{
    public void sendText(String x, String Y);
    public void receiveText(String x, String Y);
    
}
