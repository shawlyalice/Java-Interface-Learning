/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceonline;

/**
 *
 * @author Asus
 */
public abstract class ModernMessengerApp implements ModernMessenger,VideoCaller{

    public void offerExtraFeautre(String x)
    {
    }
    
    @Override
    public void sendText(String x, String Y) {
    System.out.println("Sending to "+x+" the message: "+Y);
//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void receiveText(String x, String Y) {
        System.out.println(x+" sent you the message: "+Y);
//  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void sendConnection(String x) {
    System.out.println("Trying to connect with "+x);
    }

    @Override
    public void receiveConnection(String x) {
       
        System.out.println(x+" is trying to connect with you");
    // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void sendCall(String x) {
     System.out.println("Calling "+x);

    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void receivecall(String x) {
    System.out.println(x+" is calling you");
//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
