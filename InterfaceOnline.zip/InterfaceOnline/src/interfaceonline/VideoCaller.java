/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceonline;

/**
 *
 * @author Asus
 */
public interface VideoCaller extends VoiceCaller {
 
    public void sendCall(String x);
    public void receivecall(String x);
    
}
