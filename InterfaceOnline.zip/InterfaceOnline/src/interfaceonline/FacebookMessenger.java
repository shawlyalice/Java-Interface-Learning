/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceonline;

/**
 *
 * @author Asus
 */
public class FacebookMessenger extends ModernMessengerApp {

    @Override
    public void sendPhoto(String x, String y) {
        System.out.println("Sending to "+x+" the image: "+y+".jpg");

    //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void receivePhoto(String x, String y) {
        System.out.println(x+" sent you the image: "+y+".jpg");
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void offerExtraFeature(String x)
    {
    System.out.println("Playing "+x);
    
    }
}
