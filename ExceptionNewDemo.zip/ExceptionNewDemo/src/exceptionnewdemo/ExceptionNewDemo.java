package exceptionnewdemo;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

class IDNotFoundException extends Exception {
    int id;
    public IDNotFoundException(int x) {
        id = x;
    }
    @Override
    public String toString() {
        return "ID:" + id + " Currently not online";
    }
}

class IDBlockedException extends Exception {
    int id;
    public IDBlockedException(int x) {
        id = x;
    }
    @Override
    public String toString() {
        return "ID:" + id + " Currently blocked";
    }
}


public class ExceptionNewDemo {
    public static void readOnlineList(int ID) throws FileNotFoundException, IDNotFoundException {

        Scanner reader = new Scanner(new File("online.txt"));
        while (reader.hasNext()) {
            int i = reader.nextInt();
            if (i == ID) {
                reader.close();
                return;
            }

        }
        
        throw new IDNotFoundException(ID);
    }

    public static void readBlockedList(int ID) throws FileNotFoundException, IDBlockedException {

        Scanner reader = new Scanner(new File("blocked.txt"));
        while (reader.hasNext()) {
            int i = reader.nextInt();
            if (i == ID) {
                reader.close();
        throw new IDBlockedException(ID);       
            }

        }

         return;
        
    }

    public static void main(String[] args) {

        Scanner takeInput = new Scanner(System.in);
        while (true) {
            System.out.println("Enter message");
            
            String message = takeInput.nextLine();
            System.out.println("Enter ID");
            int friendID = Integer.parseInt(takeInput.nextLine());

            try {
                readBlockedList(friendID);
                readOnlineList(friendID);
                System.out.println("Sent message: <" + message + "> to ID: " + friendID);

            } 
            catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
            catch(IDBlockedException ex)
            {
                ex.printStackTrace();
                System.out.println(ex);
            
            }
            catch (IDNotFoundException ex) {
                ex.printStackTrace();
                System.out.println(ex);
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
                System.out.println(ex);
            
            }

        }
    }

}
