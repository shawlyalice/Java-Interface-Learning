/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceonlinea2;

/**
 *
 * @author Asus
 */
public class NotepadPlusPlus implements ModernTextProcessor{

    @Override
    public void highlightSyntax(String F, String K) {
        
System.out.println("Highlighting Keyword "+K+" in File "+F+" using Notepad++");
//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void writeTextOnFile(String X, String F) {
        System.out.println("Writing text "+X+" on file "+F+" using Notepad++");    
    
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

        
}
