/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceonlinea2;

/**
 *
 * @author Asus
 */
public abstract class IDE extends ModernCompiler {

    @Override
    public void highlightSyntax(String F, String K) {
  System.out.println("Highlighting Keyword "+K);
//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void writeTextOnFile(String X, String F) {
     System.out.println("Writing on File "+F);         
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public void buildProject(String P)
    {
    System.out.println("Building project "+P);
    }
    
}
