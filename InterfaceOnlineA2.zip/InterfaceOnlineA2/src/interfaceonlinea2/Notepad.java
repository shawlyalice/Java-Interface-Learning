/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceonlinea2;

/**
 *
 * @author Asus
 */
public class Notepad implements TextProcessor{

    @Override
    public void writeTextOnFile(String X, String F) {
    System.out.println("Notepad is writing text "+X+" on file "+F);    
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
