/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceonlinea2;

/**
 *
 * @author Asus
 */
public class Netbeans extends IDE{
    @Override
    public void compile(String F) {
     System.out.println("Compiling "+F+".java");
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void buildExecutables(String F) {
        System.out.println("Building "+F+".jar");
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
